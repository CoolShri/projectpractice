package com.cg.tms.dto;

public class TicketBean {

	private String ticketCategoryId;
	private String categoryName;
	
	public TicketBean(String ticketCategoryId, String categoryName) {
		super();
		this.ticketCategoryId = ticketCategoryId;
		this.categoryName = categoryName;
	}
	public String getTicketCategoryId() {
		return ticketCategoryId;
	}
	public void setTicketCategoryId(String ticketCategoryId) {
		this.ticketCategoryId = ticketCategoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	@Override
	public String toString() {
		return "TicketBean [ticketCategoryId=" + ticketCategoryId
				+ ", categoryName=" + categoryName + "]";
	}
	
}
