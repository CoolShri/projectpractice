package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.tms.bean.TicketBean;
import com.cg.tms.bean.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO {

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		return Util.addTicketLog(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		//int k=0;
				List<TicketCategory> hList = new ArrayList<TicketCategory>();
				Map<String,String> hMap = Util.getTicketCategoryEntries();
				//Iterator itSet = hMap.keySet().iterator();
				
				String str1 = null;
				String str2 = null;
				TicketCategory tCat = null;
				
				
				for(Map.Entry<String, String> entry:hMap.entrySet()){
					str1 = entry.getKey();
					str2 = entry.getValue();
					tCat = new TicketCategory(str1, str2);
					hList.add(tCat);
	}
				
				/*while(itSet.hasNext()){
					str =  (String) itSet.getKey();
					System.out.println("A");
					System.out.println("."+str);
					//System.out.println("*"+itSet.next());
					System.out.println("B");
					
					//hList.add((TicketCategory)str);
				}
		*/
				
				//System.out.println("A");
				return hList;
			}

}
