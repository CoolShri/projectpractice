package com.cg.mp.service;

import java.util.regex.Pattern;


import com.cg.mp.bean.MobileBean;
import com.cg.mp.dao.MobilePurchaseDao;
import com.cg.mp.dao.MobilePurchaseDaoImpl;
import com.cg.mp.exception.MobilePurchaseException;

public class MobilePurchaseServiceImpl implements MobilePurchaseService {
	static MobilePurchaseDao mobiledao = new MobilePurchaseDaoImpl();
	@Override
	public int addDetails(MobileBean details) throws MobilePurchaseException {
		MobilePurchaseDao mobiledao = new MobilePurchaseDaoImpl();
		return mobiledao.addDetails(details);
	}

	@Override
	public MobileBean getDetails(String mobileId) throws MobilePurchaseException {
		return mobiledao.getDetails(mobileId);
	}

	@Override
	public boolean validateMobileNo(String mobileNumber)throws MobilePurchaseException 
	{
		if(mobileNumber.length()!=10)
        {
        throw new MobilePurchaseException("Mobile Number Can Not Be Greater than or Less than 10");
        }
        else
        {
        	
            String namePattern="[0-9]+";
            if(Pattern.matches(namePattern, mobileNumber))
            {
                return true;
            }
        	
            else
            {
                throw new MobilePurchaseException("Mobile Number is Invalid");
            }
        }
		
	
	}

	@Override
	public boolean validateCustomerName(String customerName)
			throws MobilePurchaseException {
		 if(customerName.length()>20)
	        {
	        throw new MobilePurchaseException("Name is too long!!");
	        }
	        else
	        {
	            String namePattern="[A-Z][a-z]+";
	            if(Pattern.matches(namePattern, customerName))
	            {
	                return true;
	            }
	            else
	            {
	                throw new MobilePurchaseException("Name is invalid!!");
	            }
	        }
	}

	@Override
	public boolean validateMobileId(String mobileId)
			throws MobilePurchaseException {
		 if(mobileId.length()!=4)
	        {
	        throw new MobilePurchaseException("Mobile Number Can Not Be Greater than or Less than 10");
	        }
	        else
	        {
	        	
	            String namePattern="[0-9]+";
	            if(Pattern.matches(namePattern, mobileId))
	            {
	                return true;
	            }
	        	
	            else
	            {
	                throw new MobilePurchaseException("Mobile Number is Invalid");
	            }
	        }
	}

	 @Override
	    public boolean validateMailId(String cstmrMailId) throws MobilePurchaseException {
	        // TODO Auto-generated method stub
	        String mailPattern = "[A-z]*[a-z]*[0-9]*+" + "."
	                + "[A-Z]*[a-z]*[0-9]*+" + "@capgemini.com";
	        if (Pattern.matches(mailPattern, cstmrMailId)) {
	            return true;
	        } else {
	            throw new MobilePurchaseException(
	                    "Invalid MailId Must be in the format xxxx.xxx@capgemini.com");
	        }
	    }
}
