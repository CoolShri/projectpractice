package com.cg.spring.dto;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class Main {
	@SuppressWarnings("depriciation")
	public static void main(String[] args)
	{
		XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("config.xml"));
		Test t=(Test)factory.getBean("mybean");
		System.out.println("Company Name is "+t.getCompName());
		System.out.println("Mobile Type is "+t.getType());
		System.out.println("Mobile Price is "+t.getPrice());
	}

}
