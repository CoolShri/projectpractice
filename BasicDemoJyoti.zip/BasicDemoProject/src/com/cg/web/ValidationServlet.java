package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.LogInDaoImpl;
import com.cg.dto.LogIn;


@WebServlet("/ValidationServlet")
public class ValidationServlet extends HttpServlet {
	LogInDaoImpl login=new LogInDaoImpl();
	private static final long serialVersionUID = 1L;
       
 
    public ValidationServlet() {
        super();
    }

	
	public void init(ServletConfig config) throws ServletException {
System.out.println("ValidationServlet init called");
	}

	
	public void destroy() {
		System.out.println("ValidationServlet destroy called");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request,response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		LogIn usr=null;
		RequestDispatcher rdSuccess,rdFailure=null;
PrintWriter out=response.getWriter();
String unm=request.getParameter("txtUname");
String pwd=request.getParameter("txtPwd");
 try {
	usr=login.getUserDetails(unm);
	out.println("frgfghfhcvhjfihuadfhsigfhdwgfiswhqgfihdhwdasidwhjdhsdashds"+usr.getUserName());
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
if(unm.equalsIgnoreCase(usr.getUserName()) && pwd.equalsIgnoreCase(usr.getPassword()))
{
	
	rdSuccess= request.getRequestDispatcher("/SuccessServlet");
	rdSuccess.forward(request, response);
}
else
{
	rdFailure= request.getRequestDispatcher("/FailureServlet");
	rdFailure.forward(request, response);
	}
	}

}
