package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Account {
@Id
@GeneratedValue(strategy= GenerationType.AUTO)
int AcctNo;
String AccType;
String Balance;
@ManyToOne
Customer Cust_details;

public Account()
{
	
}
public Account(String accType, String balance,
		Customer cust_details) {
	super();

	AccType = accType;
	Balance = balance;
	Cust_details = cust_details;
}
public int getAcctNo() {
	return AcctNo;
}
public void setAcctNo(int acctNo) {
	AcctNo = acctNo;
}
public String getAccType() {
	return AccType;
}
public void setAccType(String accType) {
	AccType = accType;
}
public String getBalance() {
	return Balance;
}
public void setBalance(String balance) {
	Balance = balance;
}
public Customer getCust_details() {
	return Cust_details;
}
public void setCust_details(Customer cust_details) {
	Cust_details = cust_details;
}

@Override
public String toString() {
	return "Account [AcctNo=" + AcctNo + ", AccType=" + AccType + ", Balance="
			+ Balance + ", Cust_details=" + Cust_details + "]";
}

}
