package com.cg.ems.dao;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;




import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		
		DBUtil.addEmp(ee);
		return ee.getEmpId();
	}

	@Override
	public Set<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return DBUtil.getAllEmp();
	}

	@Override
	public Employee serchEmpById(int eid) 
    {
        Set<Employee> empst1=DBUtil.getAllEmp();
        Iterator<Employee> it2=empst1.iterator();
        while(it2.hasNext())
        {
            Employee temp2=it2.next();
            if(temp2.getEmpId()==eid)
            {
                return temp2;
            }
        }
        return null;
    }

	 @Override
	    public Employee serchEmpByName(String eName)
	 {
	        Set<Employee> emps = DBUtil.getAllEmp();
	        Iterator<Employee> itSet = emps.iterator();
	        while(itSet.hasNext()){
	            Employee tempEmp = itSet.next();
	            if(tempEmp.getEmpName().equals(eName)){
	                return tempEmp;
	            }
	        }
	        return null;
	    }

	    @Override
	    public int deleteEmp(int empId) {
	        Set<Employee> emps = DBUtil.getAllEmp();
	        Iterator<Employee> itSet = emps.iterator();
	        while(itSet.hasNext()){
	            Employee tempEmp = itSet.next();
	            if(tempEmp.getEmpId() == empId){
	                itSet.remove();
	                return 1;
	            }
	        }
	        return 0;
	    }
	    @Override
        public void updateDetails(int empId){
            Set<Employee> emps=DBUtil.getAllEmp();
            Iterator<Employee> it=emps.iterator();
            Employee temp=null;
            while(it.hasNext()){
                 temp=it.next();
                if(temp.getEmpId()==empId){
                    System.out.println("Enter the updated name");
                    Scanner sc=new Scanner(System.in);
                    String name=sc.nextLine();
                    temp.setEmpName(name);
                   
                    
                }
                
            }
        
        }
		

}
