package com.cg.tms.exception;

public class TicketException extends Exception {
 public  TicketException(String msg){
		
		super(msg);

		
	}
}
