package com.cg.pizzaorder.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;


public class Client {
		static Scanner sc=null;
		static int choice;
		static boolean checkNum=false;
		static Customer cs=null;
		static PizzaOrder po=null;
		static IPizzaOrderService pos=null;
		public static void main(String[] args) throws IOException, PizzaException{
			sc=new Scanner(System.in);
			while(true)
			{
				System.out.println("********Pizza Delivery**********");
				System.out.println("Choose an operation");
				System.out.println("1. Place Order");
				System.out.println("2. Display All Pizza Order");
				System.out.println("0. Exit");
				choice=sc.nextInt();
				performOperation(choice);
				
			}
		}
		private static void performOperation(int choice) throws IOException, PizzaException {
			switch(choice)
			{
			case 1:placeOrder();break;
			case 2:diplayAllPizza();break;
			default:exitFunction();break;
			}
		}
		private static void diplayAllPizza() throws PizzaException {
			Map<Integer, PizzaOrder> pizzaSet=pos.pizzOrderDataSet();
			
			Iterator<PizzaOrder> it = pizzaSet.values().iterator();
			 System.out.println("----------------------------------------------------");
			 System.out.println("orderId\t\t"
	                 + "customerId\ttotalPrice");
			 while (it.hasNext()) {
				 PizzaOrder pizzord = it.next();
	             System.out.println(pizzord.getOrderId() + "\t\t"
	                     +pizzord.getCustomerId() + " \t\t" + pizzord.getTotalPrice());
	         }
			 System.out.println("----------------------------------------------------");
		}
		private static void exitFunction() {
			System.out.println("Thank you !!");
			System.exit(0);
		}
		
		
		
		 //* Display Pizza Order
		
		private static void diplayOrder() throws PizzaException {
			System.out.println("Enter your order Id to display pizza Details");
			int diplayPizzaId=sc.nextInt();
			PizzaOrder mypizza=pos.getOrderDetails(diplayPizzaId);
			System.out.println("------------------------------------");
			System.out.println("Customer ID "+mypizza.getCustomerId());
			System.out.println("Customer ID "+mypizza.getTotalPrice());
		}
		
		
		//* Placing pizzaOrder
		
		private static void placeOrder() throws IOException, PizzaException {
			double selectedtopping = 0;
			System.out.println("Welcome to online pizza shopping. ");
			//* customer ID
			
			Random r=new Random();
			int customerId=r.nextInt(1000);
			
			//* customer name
			
			System.out.println("Enter the name of the customer");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
			String custName=br.readLine();
			
			//* customer Address
			System.out.println("Enter customer Address");
			BufferedReader bs = new BufferedReader(new InputStreamReader(System.in));
			String address= bs.readLine();
			
			//* customer Phone
			System.out.println("Enter customer Phone number");
			String phone= sc.next();
			
			
			//* Pizza Toppings
			System.out.println("Type of pizza topping preffered");
			System.out.println("1. Capsicum - 30(in Rs)");
			System.out.println("2. Mushroom - 50(in Rs)");
			System.out.println("3. Jalapeno - 70(in Rs)");
			System.out.println("4. Paneer -   85(in Rs)");
			int pizzachoice=sc.nextInt();
			switch(pizzachoice)
			{
			case 1:{
				selectedtopping=30;
				break;
			}
			case 2:{
				selectedtopping=50;
				break;
			}
			case 3:{
				selectedtopping=70;
				break;
			}
			case 4:{
				selectedtopping=85;
				break;
			}
			
			}
			
			//* Price
			double totalPrice=350+selectedtopping;
			
			//* OrderId
			Random p=new Random();
			int orderId=p.nextInt(1000);
			
			//* System Date
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime nowDate=LocalDateTime.now();
			String date=dtf.format(nowDate);
			cs=new Customer(customerId,custName,address,phone);
			po=new PizzaOrder(orderId,customerId,totalPrice);
			pos=new PizzaOrderService();
			int placedOrderID=pos.placeOrder(cs, po);
			System.out.println("Pizza Order successfully placed with Order Id :"+placedOrderID);
			
			
			
		}
}




       

