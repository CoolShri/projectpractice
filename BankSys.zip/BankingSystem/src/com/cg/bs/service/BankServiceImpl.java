package com.cg.bs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bs.dao.BankDAO;
import com.cg.bs.dao.BankDAOImpl;
import com.cg.bs.dto.Account;
import com.cg.bs.dto.AccountHolder;
import com.cg.bs.dto.Transaction;
import com.cg.bs.exception.BankingException;



public class BankServiceImpl implements BankService
{
	BankDAO dao = null;
	AccountHolder accHolder = null;
	AccountHolder accholder1 = null;
	Account acc = null;
	List<Transaction> list = new ArrayList<Transaction>();
	List<Transaction> list1 = new ArrayList<Transaction>();
	
    public BankServiceImpl() 
    {
		dao = new BankDAOImpl();
		accHolder = new AccountHolder();
		
	}
	@Override
	public void addCustomer(AccountHolder c)
	{
		dao.addCustomer(c);	
	}

	@Override
	public Map<String, AccountHolder> fetchAllCustomer() {
		// TODO Auto-generated method stub
		return fetchAllCustomer();
	}

	@Override
	public double deposit(String username, String password, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double withdraw(String username, String password, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double showBalance(String username, String password)
			throws BankingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Transaction> printTransaction(String username, String password)
			throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String fundTransfer(String username, String password,
			long targetAccNo, double amount) throws BankingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateName(String name) throws BankingException {
		String namePattern = "[A-Z][a-z]*" + "[A-Z][a-z]*";
		if(Pattern.matches(namePattern,name))
		{
			return true;
		}
		else
		{
			throw new BankingException
			("Invalid name...  It Should Start With Capital Letter and only"
			+"Characters allowed \n example: Yashi Sinha");
		}
		
		
	}

	@Override
	public boolean validateContactNumber(String mob) throws BankingException 
	{
		String mobilePattern="^[6-9]{1}[0-9]{9}$";
		 if(Pattern.matches(mobilePattern, mob))
		 {
			return true;
		}
		else
		{
			throw new BankingException(" Invalid Mobile Number "
					+ " It should contain 10 digits and only Digits are  allowed \n example: (6/7/8/9)000000000 ");
		}
	}

	@Override
	public boolean validateUsername(String username) throws BankingException
	{
		String UsernamePattern = "[A-Z][a-z]+";
		if(Pattern.matches(UsernamePattern,username))
		{
			return true;
		}
		else
		{
			throw new BankingException
			("Invalid Username... Set Again \n example: dRsd");
		}
		
	}

	@Override
	public boolean validatePassword(String password) throws BankingException {
		String passwordPattern="[0-9]{4}";
		 if(Pattern.matches(passwordPattern, password))
		 {
			return true;
		}
		else
		{
			throw new BankingException(" Invalid Password.....Set Again \n example: 2222 ");
					
		}
	}

}
