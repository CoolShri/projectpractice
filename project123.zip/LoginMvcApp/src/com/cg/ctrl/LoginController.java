package com.cg.ctrl;

import java.awt.print.Printable;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Login;
import com.cg.service.LoginServiceImpl;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 ServletConfig config=null;
    public LoginController() {
    	
        super();
      
    }
	public void init(ServletConfig config) throws ServletException {
		  super.init(config);
		  this.config=config;
	}
	public void destroy() {
	
		//dont sysout in destroy
	}
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	try {
		LoginServiceImpl LogSer=new LoginServiceImpl();
	} catch (SQLException e) {
	
		e.printStackTrace();
	}
	String action=request.getParameter("action");
	ServletContext ctx=config.getServletContext();
	String cn=ctx.getInitParameter("compName");
	ctx.setAttribute("compNameobj",cn);
	
	
		if(action!=null)
		{
			
			RequestDispatcher rd=null;
			/*	************action showhomepage***********************/
		if(action.equalsIgnoreCase("ShowHomePage"))
		{
			rd=request.getRequestDispatcher("pages/Home.jsp");
			rd.forward(request, response);
		}
	/*	************action showloginpage***********************/
		if(action.equalsIgnoreCase("ShowLoginPage"))
		{
			rd=request.getRequestDispatcher("pages/Login.jsp");
			rd.forward(request, response);
			
		}
		/*	************action ValidateData***********************/
		if(action.equalsIgnoreCase("ValidateData"))
		{
			LoginServiceImpl LogSer = null;
		try {
			LogSer = new LoginServiceImpl();
			String un=request.getParameter("txtname");
			String pw=request.getParameter("txtpwd");
		
				Login user=LogSer.getUserDetails(un);
				if(un.equalsIgnoreCase(user.getUname())&&pw.equalsIgnoreCase(user.getPassword()))
						{
					HttpSession  session=request.getSession(true);
					session.setAttribute("usernameobj", un);
					rd=request.getRequestDispatcher("pages/Success.jsp");
					rd.forward(request, response);
						}
				else{
					String errMsg="Incorrect password";
					request.setAttribute("MsgObj", errMsg);
					
					rd=request.getRequestDispatcher("pages/Login.jsp");
					rd.forward(request, response);
				}
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
		}
		}
		else
		{
			PrintWriter out=response.getWriter();
			out.println("No Action is Defined");
		}
		
	}

}
