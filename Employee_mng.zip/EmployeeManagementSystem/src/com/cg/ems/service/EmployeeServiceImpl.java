package com.cg.ems.service;

import java.util.Set;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmployeeServiceImpl implements EmployeeService
{	EmployeeDao empDao = null;
	
	public EmployeeServiceImpl()
	{
		empDao = new EmployeeDaoImpl();
	}

	//@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.addEmployee(ee);
	}

	@Override
	public Set<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return empDao.fetchAllEmp();
	}

	@Override
	public Employee serchEmpById(int eId) {
		// TODO Auto-generated method stub
		return empDao.serchEmpById(eId);
	}

	@Override
	public Employee serchEmpByName(String eName) {
		// TODO Auto-generated method stub
		return empDao.serchEmpByName(eName);
	}
	@Override
	public void updateDetails(int empId){
		empDao.updateDetails(empId);
	}

	@Override
	public int deleteEmp(int eId) {
		// TODO Auto-generated method stub
		return empDao.deleteEmp(eId);
	}

	@Override
	public boolean validateName(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		String namePattern = "[A-Z][a-z]+";
		if(Pattern.matches(namePattern,name))
		{
			return true;
		}
		else
		{
			throw new EmployeeException
			("Invalid name... Should Start With Capital and only"
			+"Characters allowed");
		}
		
		
	}

	@Override
	public boolean validateDigit(String num) throws
	EmployeeException 
	{
		
		String digitPatter="[0-9]+";
		if(Pattern.matches(digitPatter, num))
		{
			return true;
		}
		else
		{
			throw new EmployeeException(" Invalid input "
					+ " Only Digits are  allowed ex.    4567");
		}
	}

	@Override
	public boolean validateDate(String date) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	
	

}
