package com.cg.pizzaorder.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;

public class PizzaOrderService implements IPizzaOrderService
{
	static IPizzaOrderDAO ipd=null;
	//The method to add the details in the map
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaException 
	{
		ipd=new PizzaOrderDAO();
		return ipd.placeOrder(customer,pizza);
		
		
	}
	//The method to get all the details from the map
	@Override
	public Map<Integer, PizzaOrder> getAllDetails() throws PizzaException {
			return ipd.getAllDetails();
	}
	//The method to validate mobile number
	@Override
	public boolean validMobile(String phnNum) throws PizzaException {

		String patternName="[0-9]{10}";
		if(Pattern.matches(patternName,phnNum))
		{
		return true;
		}
		return false;
		
	}
	//The method to validate name
	@Override
	public boolean validName(String name) throws PizzaException {
		String patternName="[A-Z][a-z]+";
		if(Pattern.matches(patternName,name))
		{
		return true;
		}
		return false;
	}
	//The method to validate Type of Pizza
	@Override
	public boolean validType(String type1) throws PizzaException {
		
		if(type1.equalsIgnoreCase("panner")||type1.equalsIgnoreCase("capsicum")||type1.equalsIgnoreCase("jalapeno")||type1.equalsIgnoreCase("mushroom"))
		{
			return true;
		}
		return false;
	}

	/*@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		
			return ipd.getOrderDetails(orderid); 
	}*/

}