package com.cg.tms.dao;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.ticketException;

import java.util.List;
public interface TicketDAO {

	
	boolean raiseNewTicket(TicketBean tikcetBean) throws ticketException;
	List<TicketCategory>listTicketCategory()  throws ticketException;
}
