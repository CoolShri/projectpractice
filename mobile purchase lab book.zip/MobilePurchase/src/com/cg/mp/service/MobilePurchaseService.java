package com.cg.mp.service;


import com.cg.mp.bean.MobileBean;
import com.cg.mp.exception.MobilePurchaseException;

public interface MobilePurchaseService {
	public int addDetails(MobileBean details)throws MobilePurchaseException;
	public MobileBean getDetails(String mobileId)throws MobilePurchaseException;
	
	public boolean validateMobileNo(String mobileNumber) throws MobilePurchaseException;
	public boolean validateCustomerName(String customerName) throws MobilePurchaseException;
	public boolean validateMobileId(String cmbID) throws MobilePurchaseException;
	public boolean validateMailId(String cstmrMailId) throws MobilePurchaseException;
}
