package com.cg.mob.dao;

import java.util.Map;

import com.cg.mob.dto.Mobiles;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.MobileException;

public interface MobileDao {
	   public boolean addcstmr(PurchaseDetails pur);

	   public Map<Integer,PurchaseDetails> getAllDetails() throws MobileException;
      public Map<Integer,Mobiles> getMobile();
}
