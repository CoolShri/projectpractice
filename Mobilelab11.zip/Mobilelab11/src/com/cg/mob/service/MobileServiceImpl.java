package com.cg.mob.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.mob.dao.MobileDaoImpl;
import com.cg.mob.dto.Mobiles;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.MobileException;

public class MobileServiceImpl implements MobileService {
MobileDaoImpl dao=new MobileDaoImpl();
	@Override
	public boolean addcstmr(PurchaseDetails pur)
			 {
		
		return dao.addcstmr(pur);
	}

	@Override
	public Map<Integer, PurchaseDetails> getAllDetails() throws MobileException {
		
		return dao.getAllDetails();
	}

	@Override
	public Map<Integer, Mobiles> getMobile() {
		
		return dao.getMobile();
	}

}
