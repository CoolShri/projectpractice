package com.cg.mp.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Scanner;

import com.cg.mp.exception.MobilePurchaseException;
import com.cg.mp.service.MobilePurchaseService;
import com.cg.mp.service.MobilePurchaseServiceImpl;
import com.cg.mp.bean.MobileBean;


public class Customer {
	static Scanner sc=null;
   
    static MobilePurchaseService mbser=null;
    static int choice;
    public static void main(String[] args) throws MobilePurchaseException {
        sc=new Scanner(System.in);
        while(true)
        {
            System.out.println("********Mobile Purchase System**********");
            System.out.println("Choose an operation");
            System.out.println("1. Enter Customer Details");
            System.out.println("2. View Enquiry Details By Purchase Id");
            System.out.println("0. Exit");
            choice=sc.nextInt();
            performOperation(choice);  
        }
    }
    private static void performOperation(int choice2) throws MobilePurchaseException {
        switch(choice2)
        {
        case 1:enterDetails();break;
        case 2:viewDetailsById();break;
        default:exitFunction();break;
        }
    }
        private static void exitFunction() {
            System.out.println("Thank you for selecting us!!");
            System.exit(0);
           
       }
        private static void enterDetails() throws MobilePurchaseException {

            Random r=new Random();
            int purchid=r.nextInt(1000);
            mbser=new MobilePurchaseServiceImpl(); 
            
        	
            while(true)
            {
            System.out.println("Enter Customer Name");
            String cname=sc.next();
            try
            {
            if(mbser.validateCustomerName(cname))
            {
            	while(true)
            	{
            System.out.println("Enter Customer Mobile Number");
            String cmbNo=sc.next();
            try
            {
            if(mbser.validateMobileNo(cmbNo))
            {
            	while(true)
            	{
            System.out.println("Enter Mobile ID");
            String cmbID=sc.next();
            try
            {
            if(mbser.validateMobileId(cmbID))
            {
            	while(true)
            	{
            System.out.println("Enter Customer Mail ID");
            String mailID=sc.next();
            try
            {
            if(mbser.validateMailId(mailID))
            {
            	
            		System.out.println("Enter Purchase Date");
                    String date=sc.next();
                        // String myDOB=date;
                         DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("dd-MM-yyyy");
                         LocalDate hiredate= LocalDate.parse(date,myFormat);
            
                       MobilePurchaseService      mbser=new MobilePurchaseServiceImpl();
            MobileBean mb=new MobileBean(cmbNo, cmbID, purchid, cname, mailID, hiredate);
            mbser.addDetails(mb);
            System.out.println(mb);
            System.out.println("Thank you " +mb.getCustName()+"  Your Purchase Id is "+mb.getPurchId()+" you are registered. ");
            break;
            }
            }
            
        catch(MobilePurchaseException e)
        {
            System.out.println(e.getMessage());
        }
            }
            	break;
            }
            }
            catch(MobilePurchaseException e)
            {
                System.out.println(e.getMessage());
            }
                }
            	break;
            }
            }
            catch(MobilePurchaseException e)
            {
                System.out.println(e.getMessage());
            }
                }
            	break;
            }
            }
            catch(MobilePurchaseException e)
            {
                System.out.println(e.getMessage());
            }
                }
    }

        
        private static void viewDetailsById() throws MobilePurchaseException {
            MobilePurchaseService mbser1=new MobilePurchaseServiceImpl();
            System.out.println("Enter the ID by which you want to search");
            Scanner sc=new Scanner(System.in);
            String purchid=sc.next();
            MobileBean mb=mbser1.getDetails(purchid);
            if(mb!=null)
            {
            	//System.out.println(mb);
           System.out.println("Customer Name :"+mb.getCustName());
            System.out.println("Mail Id :"+mb.getMbId());
            System.out.println("Contact Number :"+mb.getMbNo());
            System.out.println("Mobile Id :"+mb.getMbId());
            System.out.println("Purchase Date :"+mb.getPurchDate());
            }
            else
            {
                System.out.println("Sorry no details found!!");
            }
            
        }
}
