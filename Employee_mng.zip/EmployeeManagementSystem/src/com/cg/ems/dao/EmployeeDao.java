package com.cg.ems.dao;
import java.util.Set;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeDao 
{
	public int addEmployee(Employee ee)throws 
	EmployeeException;
	public Set<Employee> fetchAllEmp();
	public Employee serchEmpById(int eId);
	public Employee serchEmpByName(String eName);
	public void updateDetails(int empId);
	public int deleteEmp(int eId);
}
