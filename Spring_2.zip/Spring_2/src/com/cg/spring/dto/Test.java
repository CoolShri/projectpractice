package com.cg.spring.dto;

public class Test 
{

	private String compName;
	private String type;
	private int price;
	
	public String getCompName() {
		return compName;
	}
	public String getType() {
		return type;
	}
	public int getPrice() {
		return price;
	}
	public Test(String compName, String type, int price) {
		super();
		this.compName = compName;
		this.type = type;
		this.price = price;
	}

}
