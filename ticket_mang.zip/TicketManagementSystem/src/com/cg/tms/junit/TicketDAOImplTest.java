package com.cg.tms.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.tms.bean.TicketBean;
import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.exception.TicketException;

public class TicketDAOImplTest {
	int max = 1000000;
	int min = 10000;
	int range = max - min + 1;

	static TicketDAO tDao = null;

	@BeforeClass
	public static void setUp() {
		tDao = new TicketDAOImpl();
	}

	@Test
	public void addTicketTest() throws TicketException {
		int rand = (int) (Math.random() * range) + min;
		Assert.assertEquals(true, tDao.raiseNewTicket(new TicketBean(Integer
				.toString(rand), "1",
				"I am unable to install eclipse on my system", "3", "new",
				"This ticket needs to be checked immediately")));
	}
}
