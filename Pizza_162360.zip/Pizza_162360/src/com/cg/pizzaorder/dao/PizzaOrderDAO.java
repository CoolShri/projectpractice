package com.cg.pizzaorder.dao;

import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.util.DBUtil;

public class PizzaOrderDAO implements IPizzaOrderDAO {

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaException {
		return DBUtil.placeOrder(customer, pizza);
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		return DBUtil.getOrderDetails(orderid);
	}

	@Override
	public Map<Integer, PizzaOrder> pizzOrderDataSet() throws PizzaException {
		return DBUtil.pizzOrderDataSet();
	}

}
