    package com.cg.pizzaorder.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public class DBUtil 
{
	static int count;
	static Map<Integer,PizzaOrder> pizzaEntry=new HashMap<>();

	static Map<Integer,Customer> customerEntry=new HashMap<>();
	
	public static Map<Integer,PizzaOrder> addOrder(Customer customer,PizzaOrder pizza)
	{
		count++;
		pizzaEntry.put(pizza.getOrderId(),pizza);
		customerEntry.put(count,customer);
		return  pizzaEntry;
	}
	public static Map<Integer,PizzaOrder> getAllDetails()
	{
		return pizzaEntry;
		
	}
}
