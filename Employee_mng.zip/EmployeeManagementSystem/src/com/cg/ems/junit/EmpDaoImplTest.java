package com.cg.ems.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public class EmpDaoImplTest {
	static EmployeeDao empDao=null;
	@BeforeClass
	public static void  setUp()
	{
		empDao=new EmployeeDaoImpl();
		System.out.println("This function is called once"
	+" before the execution of all test cases.");
	}
	
	@AfterClass
	public static void tearDown()
	{
		System.out.println("This function is called once"
				+" after the execution of all test cases.");
	}
	@Before
	public void init()
	{
		System.out.println("This function is called"
				+"before the execution of each test cases");
	}
	@After
	public void destroy()
	{
		System.out.println("This function id called"
				+"after the execution of each test cases");
	}
	@Test
	public void testAddEmp() throws EmployeeException
	{
		Assert.assertEquals(111,empDao.addEmployee(new
				Employee(111,"aaa",1000.0f,null)));
	}
	@Test
	public void testfetAllEmp()
	{
		Assert.assertNotNull(empDao.fetchAllEmp());
	}
}
