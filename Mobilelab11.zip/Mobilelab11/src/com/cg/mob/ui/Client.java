package com.cg.mob.ui;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;




import com.cg.mob.dto.Mobiles;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.MobileException;
import com.cg.mob.service.MobileServiceImpl;

public class Client {
static Scanner sc=new Scanner(System.in);
static MobileServiceImpl mobSer=new MobileServiceImpl();
	public static void main(String[] args) throws MobileException {
	int choice;
	while(true)
	{
		 System.out.println("What you like to do:");
         System.out.println("1. Add Customer");
         System.out.println("2. Show all customers");
         choice=sc.nextInt();
         switch(choice)
         {
         case 1:addcstmr();
                  break;
         case 2:showAllDetails();
                 break;
         default : System.exit(0);
         }
	}

	}
	private static void showAllDetails() throws MobileException {
		 Map<Integer, PurchaseDetails> purMap = mobSer.getAllDetails();
	        Iterator<PurchaseDetails> it = purMap.values().iterator();

	        System.out
	                .println("----------------------------------------------------");
	        System.out.println("CustomerName\tMailId\t\t\t\t"
	                + "PhoneNumber\tMobileId  PurchaseId\tPurchaseDate");
	        while (it.hasNext()) {
	            PurchaseDetails pd = it.next();
	            System.out.println(pd.getCname() + "\t" + pd.getMailid()
	                    + "\t" + pd.getPhoneno() + "\t" + pd.getMobileid()
	                    + "\t  " + pd.getPurchaseid() + "\t\t"
	                    + pd.getPurchasedate());
	        }
	        System.out
	                .println("----------------------------------------------------");

	    }
		
	
	private static void addcstmr() {
	
		Map<Integer,Mobiles> m1=mobSer.getMobile();
		for (Map.Entry<Integer,Mobiles> data : m1.entrySet())
		{
		data.getKey();
		Mobiles mobile=data.getValue();
		System.out.println("Select type of mobile"+mobile);
		}
		String Purchaseid=String.valueOf(Math.random());
		String str=sc.next();
		System.out.println("Enter your name");
		String cName=sc.next();
		System.out.println("Enter your mailid");
		String mailid=sc.next();
		System.out.println("Enter phoneno");
		String phoneno=sc.next();
		Date d=new Date();	
		PurchaseDetails pd=new PurchaseDetails(Purchaseid,cName,mailid,phoneno,d,str);
		if(mobSer.addcstmr(pd))
		{
			System.out.println("Your Purchaseid"+ Purchaseid +"has been Logged successfully"+ d.toString());
		}
		
		
	}

}
