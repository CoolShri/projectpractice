package com.cg.ems.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashSet;
import java.util.Set;

import com.cg.ems.dto.Employee;

public class DBUtil 
{
	public static HashSet<Employee>empSet
	= new HashSet<Employee>();
	static 
	{
		empSet.add(new Employee(111565,"Mishthi", 2000.0F,
				 LocalDate.of(2014,Month.MARCH,03)));
		
		empSet.add(new Employee(112363,"Honey", 32000.0F,
				 LocalDate.of(2014,Month.SEPTEMBER,23)));
		
		empSet.add(new Employee(113454,"Shubhi", 25000.0F,
				 LocalDate.of(2014,Month.MAY,28)));
		
		empSet.add(new Employee(114656,"Amol", 29000.0F,
				 LocalDate.of(2014,Month.JANUARY,13)));
		
		empSet.add(new Employee(115258,"Yashi", 2300.0F,
				 LocalDate.of(2014,Month.JULY,12)));
	}
	
	public static Set<Employee> getAllEmp()
	{
		return empSet;
	}
	public static void addEmp(Employee ee)
	{
		empSet.add(ee);
	}
	public static Employee getserchByEmpId(int eId) {
		
		return null;
	}
}
