package com.cg.mob.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.mob.dto.Mobiles;
import com.cg.mob.dto.PurchaseDetails;

public class DBUtil {
	static int k=1;
	private static Map<Integer,Mobiles> b=new HashMap<Integer,Mobiles>();
	public static Map<Integer,Mobiles> getMobile(){
	return b;
	}
	static
	{
		b.put(1,new Mobiles("1", "Samsung","50"));
		b.put(2,new Mobiles("2", "Apple","50"));
		b.put(3,new Mobiles("3", "Mi","50"));
	}
	
	private static Map<Integer,PurchaseDetails> m=new HashMap<Integer,PurchaseDetails>();
	public static boolean addCstmr(PurchaseDetails pd) {
	m.put(k++, pd);
		return true;
	}
	public static Map<Integer, PurchaseDetails> getAllDetails() {
	
		return m;
	}

	
}
