package com.cg.tms.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.tms.bean.TicketBean;
import com.cg.tms.bean.TicketCategory;
import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.exception.TicketException;

public class TicketServiceImpl implements TicketService {
	static TicketDAO tDao = null;

	public TicketServiceImpl() {
		tDao = new TicketDAOImpl();
	}

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {

		return tDao.raiseNewTicket(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketCategory() {

		return tDao.listTicketCategory();
	}

	@Override
	public boolean valiadteChoice(String choice) throws TicketException {
		String myPattern = "[0-9]";
		if (Pattern.matches(myPattern, choice)) {
			return true;
		} else {
			throw new TicketException(
					"Invalid Input choice can enter only one digit integer 1 or 2  "
							+ "eg.  2");
		}
	}

	@Override
	public boolean valiadteOption(String option) throws TicketException {
		String myPattern = "[1-3]";
		if (Pattern.matches(myPattern, option)) {
			return true;
		}

		else {
			throw new TicketException(
					"Invalid Input choice can enter only one digit "
							+ "integer 1 or 2 or 3 eg.  2");
		}
	}

}
