package com.cg.mob.dto;

public class Mobiles {
private String mobileId;
private String name;
private String price;
public Mobiles(String mobileId, String name, String price) {
	super();
	this.mobileId = mobileId;
	this.name = name;
	this.price = price;
}
@Override
public String toString() {
	return "Mobiles [mobileId=" + mobileId + ", name=" + name + ", price="
			+ price + "]";
}
public String getMobileId() {
	return mobileId;
}
public void setMobileId(String mobileId) {
	this.mobileId = mobileId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
}
