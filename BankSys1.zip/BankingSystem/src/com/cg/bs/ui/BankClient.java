package com.cg.bs.ui;

import java.io.IOException;
import java.util.Scanner;

import com.cg.bs.dto.Account;
import com.cg.bs.dto.AccountHolder;
import com.cg.bs.exception.BankingException;
import com.cg.bs.service.BankService;
import com.cg.bs.service.BankServiceImpl;

public class BankClient 
{
	static Scanner sc = null;
	static AccountHolder customer = null;
	static Account account = null;
	static BankService service = null;
	static String username,password;
	static int choice;
	static String add;
	
	public static void main(String[] args) throws BankingException, IOException
	{
		sc=new Scanner(System.in);
		service = new BankServiceImpl();
		menuDriven();
	}
	public static void menuDriven() throws BankingException, IOException
	{
		while(true)
		{
			System.out.println("\n-------------------------");
			System.out.println("BANK OF XYZ");
			System.out.println("---------------------------\n");
			System.out.println("1: Register Account");
			System.out.println("2: Login");
			System.out.println("3: Exit");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				createAccount();
				break;
				
			}
		}
	}
}
