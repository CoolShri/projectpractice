package com.cg.swd;

public class Department 
{
	String deptName;


	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
}
