    
    package com.cg.pizzaorder.service;

import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService 
{
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaException;
	//public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
	public Map<Integer,PizzaOrder> getAllDetails() throws PizzaException;
	public boolean validMobile(String phnNum) throws PizzaException;
	public boolean validName(String name) throws PizzaException;
	public boolean validType(String type) throws PizzaException;
}
