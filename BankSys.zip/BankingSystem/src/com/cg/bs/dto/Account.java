package com.cg.bs.dto;

import java.util.List;
import java.util.Random;

public class Account
{
	private long accountNumber;
	private double balance;
	private List<Transaction> transactions;
	private static Random rand = new Random();
	
	public Account()
	{
		super();
		this.accountNumber = rand.nextInt(50) + 1;
		this.balance = 0;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	public static Random getRand() {
		return rand;
	}
	public static void setRand(Random rand) {
		Account.rand = rand;
	}
	public Account(long accountNumber, double balance
			) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
		
	}
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", balance="
				+ balance + "]";
	}
	
	
	

}
