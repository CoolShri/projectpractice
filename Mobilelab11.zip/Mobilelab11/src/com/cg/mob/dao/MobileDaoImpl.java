package com.cg.mob.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mob.dto.Mobiles;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.MobileException;
import com.cg.mob.util.DBUtil;

public class MobileDaoImpl implements MobileDao {


	@Override
	  public Map<Integer, PurchaseDetails> getAllDetails() throws MobileException {
		return DBUtil.getAllDetails();
	}

	@Override
	public Map<Integer, Mobiles> getMobile() {
		
		return DBUtil.getMobile();
	}

	public boolean addcstmr(PurchaseDetails pur) {
	
		return DBUtil.addCstmr(pur);
	}

}
