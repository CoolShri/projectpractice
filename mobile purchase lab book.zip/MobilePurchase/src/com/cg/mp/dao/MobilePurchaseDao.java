package com.cg.mp.dao;

import com.cg.mp.bean.MobileBean;
import com.cg.mp.exception.MobilePurchaseException;

public interface MobilePurchaseDao {
	public int addDetails(MobileBean details)throws MobilePurchaseException;
	public MobileBean getDetails(String mobileId)throws MobilePurchaseException;
	
}
