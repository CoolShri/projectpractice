package com.cg.hms.dao;

import java.util.HashMap;

import com.cg.hms.dto.Patient;
import com.cg.hms.exception.PatientException;
import com.cg.hms.util.PatientUtil;

public class PatientDaoImpl implements PatientDao {
	PatientUtil putil= new PatientUtil();

	@Override
	public int addPatient(Patient ee) throws PatientException {
		return putil.addPatient(ee);
	}

	

	@Override
	public int delPatient(int regNum) {
		return putil.delPatient(regNum);
	}

	@Override
	public Patient SearchByRegNum(int regNum) {
		return putil.SearchRegNum(regNum);
	}

	@Override
	public Patient SearchByName(String patName) {
		return putil.SearchByName(patName);
	}

	@Override
	public Patient SearchByRoomNum(int roomNum) {
		return putil.SearchByRoomNum(roomNum);
	}

	@Override
	public Patient UpdatePatient(int regNum, int RoomNum) {
		return putil.UpdatePatient(regNum,RoomNum);
	}

	@Override
	public HashMap<Integer, Patient> fetchAll() {
		return putil.fetchAll();
	}



	public Patient getPatientDetails(int regNum) {
		return putil.getPatientDetails(regNum);
	}

}
