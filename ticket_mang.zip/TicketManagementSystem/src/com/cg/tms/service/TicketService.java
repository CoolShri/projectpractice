package com.cg.tms.service;

import java.util.List;

import com.cg.tms.bean.TicketBean;
import com.cg.tms.bean.TicketCategory;
import com.cg.tms.exception.TicketException;

public interface TicketService {
	boolean raiseNewTicket(TicketBean ticketBean);
	List<TicketCategory> listTicketCategory();
	public boolean valiadteChoice(String choice) throws TicketException;
	public boolean valiadteOption(String option) throws TicketException;
}
