package com.cg.ems.service;

import java.util.Set;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeService 
{
	public int addEmployee(Employee ee)throws 
	EmployeeException;
	public Set<Employee> fetchAllEmp();
	public Employee serchEmpById(int eId);
	public Employee serchEmpByName(String eName);
	public int deleteEmp(int eId);
	public void updateDetails(int empId);
	public boolean validateName(String name)throws
	EmployeeException;
	public boolean validateDigit(String id)throws
	EmployeeException;
	public boolean validateDate(String date)throws
	EmployeeException;
	
}
