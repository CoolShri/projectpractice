package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketBean;

public class Util {

	
	private  static Map<String,String>ticketCategory=new HashMap<String,String>();
	public static Map<String,String>getTicketCategoryEntries()
	{
		ticketCategory.put("tc001", "Software Installation");
		ticketCategory.put("tc002", "Mailbox Creation");
		ticketCategory.put("tc003", "Mailbox issue");
		return ticketCategory;
	}
	
	private  static Map<String,TicketBean>ticketBean=new HashMap<String,TicketBean>();
	
	
public boolean	raiseNewTicket(TicketBean tb)
	{//adding data to different maps
	ticketCategory.put(tb.getTicketCategoryId(), tb.getCategoryName());
	ticketBean.put(tb.getTicketCategoryId(),tb);
		return true;
		
	}
}
