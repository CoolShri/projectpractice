package com.cg.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.bean.Account;
import com.cg.bean.Customer;
import com.cg.service.payserviceImpl;

public class MobileUI {

	public static void main(String[] args) throws IOException {
	
		Scanner sc=new Scanner(System.in);
	System.out.println("welcome to xyz mobile wallet");
	while(true)
	{
	System.out.println("choose the operation");
	System.out.println("1.Create Account");
	System.out.println("2.show balance");
	System.out.println("3.Deposit");
	System.out.println("4.Withdraw");
	System.out.println("5.Fund Transfer");
	System.out.println("6.Print Transaction");
	System.out.println();

	int chioce=sc.nextInt();
	
	switch(chioce)
	{
	case 1:Create_Account();
	break;
	
	case 2:Show_Balance();
	break;
	
	case 3:Deposit();
	break;
	
	case 4:Withdraw();
	break;
	
	case 5:Fund_Transfer();
	break;
	
	case 6:Print_Transaction();
	break;
	
	default :System.out.println("********Invalid choice**********");
	}
	}

	}

	private static void Create_Account() throws IOException {
		
         String acctype;
	   	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		payserviceImpl pser1=new payserviceImpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome");
		System.out.println("fill the asked Details");
		System.out.println("Enter your name");
		String name=sc.next();
		System.out.println("phone number");
		
		String phoneNo=sc.next();
		
		System.out.println("Date of birth");
		String dob =sc.next();
		
		
		System.out.println("enter addhar number");
		String id_proof =sc.next();
		
		System.out.println("enter address");
		String address=br.readLine();
		System.out.println("select account type");
		System.out.println("1.Saving");
		System.out.println("2.Current");
		int choice=sc.nextInt();
		if(choice==1)
		{
			acctype="Saving";
		}
		else
		{
			 acctype="Current";
		}
	System.out.println("enter the balance");
	String bal=sc.next();
	   
		 Customer cust=new Customer(name, phoneNo, dob, id_proof, address);
	Account acc=new Account(acctype,bal,cust);
	int k=pser1.createAccount(cust,acc);
	 
		 System.out.println("your account has been Created with Account no "+k);
	
	 
		
}

	private static void Show_Balance() {
		Scanner sc=new Scanner(System.in);
	System.out.println("enter the account number");
	String accno=sc.next();
	payserviceImpl pser2=new payserviceImpl();
int curr_bal=pser2.show_balance(Integer.valueOf(accno));
System.out.println("Your Current Balance is "+curr_bal);
		
	}

	    private static void Deposit() {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("JPA-PU");
	    EntityManager entitymanager = emfactory.createEntityManager();
		payserviceImpl pser3=new payserviceImpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your account number");
		String accno=sc.next();
		System.out.println("enter the amount to be deposited");
		String amt=sc.next();
	    int acc_no=Integer.valueOf(accno);
		int bal=Integer.valueOf(amt);
	    int new_bal=pser3.updateBalance(acc_no, bal);
	    String balnce=String.valueOf(new_bal);
		System.out.println("Your Account balance is "+balnce);
	
	}

	private static void Withdraw() {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("JPA-PU");
	    EntityManager entitymanager = emfactory.createEntityManager();
		payserviceImpl pser3=new payserviceImpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your account number");
		String accno=sc.next();
		System.out.println("enter the amount to be withdraw");
		String amt=sc.next();
	    int acc_no=Integer.valueOf(accno);
		int bal=Integer.valueOf(amt);
	    int new_bal=pser3.withdraw(acc_no, bal);
	    String balnce=String.valueOf(new_bal);
		System.out.println("Your Account balance is "+balnce);
	
		
	}

	private static void Fund_Transfer() {
		Scanner sc=new Scanner(System.in);
		payserviceImpl pser4=new payserviceImpl();
	System.out.println("enter your account number");
	String myacc=sc.next();
	int myacc1=Integer.valueOf(myacc);
	System.out.println("enter reciever account number");
	String depacc=sc.next();
	int depacc1=Integer.valueOf(depacc);
	System.out.println("enter the amount to transfer");
	String amt=sc.next();
	int amt1=Integer.valueOf(amt);
	int curr_bal=pser4.fundTransfer(myacc1,depacc1,amt1);
	System.out.println(" Remaining Balance for "+myacc1+" is "+curr_bal);
		
	}

	private static void Print_Transaction() {
	System.out.println("Enter your account number");
	Scanner sc=new Scanner(System.in);
	int acc=sc.nextInt();
		
	}



}
	
