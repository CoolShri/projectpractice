    package com.cg.pizzaorder.dao;

import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.util.DBUtil;


public class PizzaOrderDAO implements IPizzaOrderDAO
{
	//The method to add the details in the map
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaException {
		DBUtil.addOrder(customer, pizza);
		return pizza.getOrderId();
		
	}
	//The maethod to get all the details from the map
	@Override
	public Map<Integer, PizzaOrder> getAllDetails() throws PizzaException {
		
				return DBUtil.getAllDetails();
	}

}
