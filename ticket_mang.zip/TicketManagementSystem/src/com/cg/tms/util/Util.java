package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.bean.TicketBean;

public class Util {
	 private static Map<String, String> TicketCategory = new HashMap<String,String>();
	 public static Map<String,String> getTicketCategoryEntries(){
		 TicketCategory.put("tc001","software installation");
		 TicketCategory.put("tc002","mailbox creation");
		 TicketCategory.put("tc003","mailbox Issues");
		 
		 return TicketCategory;
	 }
	 private static Map<Integer, TicketBean> TicketLog = new HashMap<Integer,TicketBean>();
	 public static Map<Integer, TicketBean> getTicketLog(){
		 return TicketLog;
	 }
	 public static boolean addTicketLog(TicketBean tBean){
		int rand = Integer.parseInt(tBean.getTicketNo());
		 if(TicketLog.put(rand,tBean) == null){
		 return true;
		 } 
		 return false;
	 }
}
