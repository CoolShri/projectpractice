package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.LogIn;
import com.cg.util.DBUutil;

public class LogInDaoImpl 
{
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	public LogInDaoImpl()
	{
		
	}
	public LogIn getUserDetails(String unm) 
	{
		
	con=DBUutil.getCon();
	System.out.println("In dao got Connection :"+con);
	String sql="Select * from test Where username=?";
	LogIn usr=null;
		try {
			pst=con.prepareStatement(sql);
			pst.setString(1, unm);
			rs=pst.executeQuery();
			rs.next();
			
			String password1=rs.getString("password");
			String username1=rs.getString("username");
			usr=new LogIn(username1, password1);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	return usr;


}}
