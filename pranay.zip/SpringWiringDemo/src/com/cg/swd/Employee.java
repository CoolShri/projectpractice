package com.cg.swd;

public class Employee 
{
	int empId;
	String empName;
	Department dept;

	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public Department getDept() {
		return dept;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public String getDeptName()
	{
	return dept.getDeptName();
	}
			
}
