package com.cg.mp.bean;

import java.time.LocalDate;

public class MobileBean {
	
	 String MbNo;
	 String MbId;
	 int PurchId;
	 String CustName;
	 String MailId;
	 LocalDate PurchDate;
	public MobileBean(String mbNo, String mbId, int purchId, String custName,
			String mailId, LocalDate purchDate) {
		super();
		MbNo = mbNo;
		MbId = mbId;
		PurchId = purchId;
		CustName = custName;
		MailId = mailId;
		PurchDate = purchDate;
	}
	@Override
	public String toString() {
		return "MobileBean [MbNo=" + MbNo + ", MbId=" + MbId + ", PurchId="
				+ PurchId + ", CustName=" + CustName + ", MailId=" + MailId
				+ ", PurchDate=" + PurchDate + "]";
	}
	public String getMbNo() {
		return MbNo;
	}
	public void setMbNo(String mbNo) {
		MbNo = mbNo;
	}
	public String getMbId() {
		return MbId;
	}
	public void setMbId(String mbId) {
		MbId = mbId;
	}
	public int getPurchId() {
		return PurchId;
	}
	public void setPurchId(int purchId) {
		PurchId = purchId;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getMailId() {
		return MailId;
	}
	public void setMailId(String mailId) {
		MailId = mailId;
	}
	public LocalDate getPurchDate() {
		return PurchDate;
	}
	public void setPurchDate(LocalDate purchDate) {
		PurchDate = purchDate;
	}
}