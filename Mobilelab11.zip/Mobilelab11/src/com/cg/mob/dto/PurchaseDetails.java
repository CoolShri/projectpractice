package com.cg.mob.dto;

import java.util.Date;

public class PurchaseDetails {
private String purchaseid;
private String cname;
private String mailid;
private String phoneno;
private Date purchasedate;
private String mobileId;

public PurchaseDetails(String purchaseid, String cname, String mailid,
		String phoneno, Date purchasedate, String mobileId) {
	super();
	this.purchaseid = purchaseid;
	this.cname = cname;
	this.mailid = mailid;
	this.phoneno = phoneno;
	this.purchasedate = purchasedate;
	this.mobileId = mobileId;
}
@Override
public String toString() {
	return "PurchaseDetails [purchaseid=" + purchaseid + ", cname=" + cname
			+ ", mailid=" + mailid + ", phoneno=" + phoneno + ", purchasedate="
			+ purchasedate + ", mobileid=" + mobileId + "]";
}
public String getPurchaseid() {
	return purchaseid;
}
public void setPurchaseid(String purchaseid) {
	this.purchaseid = purchaseid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public String getPhoneno() {
	return phoneno;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}

public Date getPurchasedate() {
	return purchasedate;
}
public void setPurchasedate(Date purchasedate) {
	this.purchasedate = purchasedate;
}
public String getMobileid() {
	return mobileId;
}
public void setMobileid(String mobileid) {
	this.mobileId = mobileid;
}
}
