package com.cg.util;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;


import com.cg.bean.Account;
import com.cg.bean.Customer;

public class util {
	EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("JPA-PU");
    EntityManager entitymanager = emfactory.createEntityManager();
	public int createAccount(Customer cust,Account acc)
	{
		 entitymanager.getTransaction( ).begin( );
		   entitymanager.persist(cust);
		   entitymanager.persist(acc);
		   entitymanager.getTransaction().commit();
		return acc.getAcctNo();      
		
	}
	public int show_balance(int accno)
	{ 
		entitymanager.getTransaction( ).begin( );
		Account account=entitymanager.find(Account.class, accno);
		int a=Integer.parseInt(account.getBalance());
	   entitymanager.getTransaction().commit();
	
		return 	a;
	}
	public int updateBalance(int accno,int bal)
	{
		entitymanager.getTransaction( ).begin( );
		Account account=entitymanager.find(Account.class, accno);
		int a=Integer.valueOf(account.getBalance())+bal;
		account.setBalance(String.valueOf(a));
		entitymanager.persist(account);
	 entitymanager.getTransaction().commit();
	return a;
	}
	
	public int withdraw(int accno,int bal) {
		entitymanager.getTransaction( ).begin( );
		Account account=entitymanager.find(Account.class, accno);
		int a=Integer.valueOf(account.getBalance())-bal;
		account.setBalance(String.valueOf(a));
		entitymanager.persist(account);
	 entitymanager.getTransaction().commit();
	return a;
	}
	
	public int fundTransfer(int myacc,int depacc,int bal)
	{
		entitymanager.getTransaction( ).begin( );
		Account payee=entitymanager.find(Account.class, myacc);
		int a=Integer.valueOf(payee.getBalance())-bal;
		payee.setBalance(String.valueOf(a));
		entitymanager.persist(payee);
		
		Account reciever=entitymanager.find(Account.class, depacc);
		int b=Integer.valueOf(reciever.getBalance())+bal;
		reciever.setBalance(String.valueOf(b));
		entitymanager.persist(reciever);
		 entitymanager.getTransaction().commit();
		return a;
	}
}
