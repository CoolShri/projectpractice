package com.cg.bs.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.bs.dto.AccountHolder;

public class DBUtil
 {
	public static Map<String, AccountHolder> map = new HashMap<String, AccountHolder>();
	{
    }
	
	public static void addAccount(AccountHolder c)
	{
		map.put(c.getUsername(),c);
	}
	
	public static Map<String, AccountHolder> getAllCus()
	{
		return map;
	}

}