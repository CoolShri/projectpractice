package com.cg.hms.service;

import java.util.HashMap;
import java.util.regex.Pattern;

import com.cg.hms.dao.PatientDaoImpl;
import com.cg.hms.dto.Patient;
import com.cg.hms.exception.PatientException;

public class PatientServiceImpl implements PatientService {
	PatientDaoImpl pdao= new PatientDaoImpl();

	@Override
	public int addPatient(Patient ee) throws PatientException {
		return pdao.addPatient(ee);
	}

	

	@Override
	public int delPatient(int regNum) {
		return pdao.delPatient(regNum);
	}

	@Override
	public Patient SearchByRegNum(int regNum) {
		return pdao.SearchByRegNum(regNum);
	}

	@Override
	public Patient SearchByName(String patName) {
		return pdao.SearchByName(patName);
	}

	@Override
	public Patient SearchByRoomNum(int roomNum) {
		return pdao.SearchByRoomNum(roomNum);
	}

	@Override
	public Patient UpdatePatient(int regNum, int RoomNum) {
		return pdao.UpdatePatient(regNum, RoomNum);
	}

	@Override
	public HashMap<Integer, Patient> fetchAll() {
		return pdao.fetchAll();
	}



	@Override
	public Patient getPatientDetails(int regNum) {
		return pdao.getPatientDetails(regNum);
	}



	@Override
	public boolean validateName(String patName)
	{
		String pattern = "[A-Z][a-z]+{8}";
		if(Pattern.matches(pattern, patName))
		{
			return true;
		}
		else
		{
		return false;
		}
	}



	@Override
	public boolean validateRoomNum(String roomNum)
	{
		String pattern = "[0-9]{3}";
		if(Pattern.matches(pattern, roomNum))
		{
			return true;
		}
		return false;
	}



	@Override
	public boolean validateAge(String Age) {
		// TODO Auto-generated method stub
		return false;
	}

}
