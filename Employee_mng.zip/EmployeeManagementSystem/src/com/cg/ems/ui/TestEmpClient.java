package com.cg.ems.ui;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class TestEmpClient
{
		static EmployeeService empSer = null;
	static Scanner sc = null;
	public static void main(String[] args)
	{
		empSer = new EmployeeServiceImpl();
		sc=new Scanner(System.in);
		int choice;
		while(true)
		{
			System.out.println(" What Do u Wnt To Do?");
			System.out.println(" 1:Add Emp\t2:Get All Emp Info\n");
			System.out.println(" 3:Update Emp\t4:Search Emp by Id\n");
			System.out.println(" 5:Search Emp By Name\t6:Delete Emp\n");
			System.out.println(" 7:Exit");
			System.out.println("Enter Ur Choice");
			choice = sc.nextInt();
			performOperation(choice);
		}

	}
	private static void performOperation(int choice)
	{
		switch(choice)
		{
		case 1:addEmp();break;
		case 2:showEmpInfo();break;
		case 3:updateEmp();break;
		case 4:serchEmpById();break;
		case 5:serchEmpByName();break;
		case 6:deleteEmp();break;
		default:System.out.println("Enter valid input");System.exit(0);
		}
	}
    
    private static void serchEmpById() {
    	while(true){
        EmployeeService emp = new EmployeeServiceImpl(); 
        int sEmpId = 0;
        System.out.println("Enter Employee Id: ");
        sEmpId = sc.nextInt();
        Employee srch = emp.serchEmpById(sEmpId);
        if(srch != null){
            System.out.println(srch.getEmpId()+"\t"+srch.getEmpName()+"\t"+srch.getEmpSal()+"\t"+srch.getEmpDOJ());
            break;
        }
        else{
            System.out.println("No Employee Found.");
        }
    	}
    }
    private static void serchEmpByName() {
    	while(true){
        String sEmpName = null;
        System.out.println("Enter Employee Name: ");
        sEmpName = sc.next();
        EmployeeService emp = new EmployeeServiceImpl(); 
        Employee srch = emp.serchEmpByName(sEmpName);
        if(srch != null){
            System.out.println(srch.getEmpId()+"\t"+srch.getEmpName()+"\t"+srch.getEmpSal()+"\t"+srch.getEmpDOJ());
            break;
        }
        else{
            System.out.println("No Employee Found.");
        }
    	}
    }
    private static void updateEmp() {
        EmployeeService emp1=new EmployeeServiceImpl();
        System.out.println("Enter the ID you want to update");
        int eid=sc.nextInt();
        emp1.updateDetails(eid);
        
    }
	private static void showEmpInfo()
	{
		Set<Employee> emps=empSer.fetchAllEmp();
		Iterator<Employee> itSet=emps.iterator();
		System.out.println("ID\\ttName\\ttSALARY\\ttDateOfJoining");
		System.out.println("---------------------------");
		while(itSet.hasNext())
		{
			Employee tempEmp = itSet.next();
			System.out.println(tempEmp.getEmpId()+"\t"+
			tempEmp.getEmpName()+"\t"+tempEmp.getEmpSal()+"\t"+
					tempEmp.getEmpDOJ());
		}
	}
	private static void addEmp()
	{
		while(true)
		{
		System.out.println("Enter Employee Name");
		String ename = sc.next();
		try
		{
		if(empSer.validateName(ename))
		{
			while(true)
			{
		System.out.println("Enter Employee Id:");
		String eId=sc.next();
		try
		{
			if(empSer.validateDigit(eId))
			{
			while(true)
			{
		System.out.println("Enter salary:");
		String sal=sc.next();
		try
		{
			if(empSer.validateDigit(sal))
			{
		
		Employee ee=new Employee(Integer.parseInt(eId),ename,Integer.parseInt(sal),null);
		empSer.addEmployee(ee);
		System.out.println(" data added");
		break;
		}
		
		}
		catch(EmployeeException e)
		{
			System.out.println(e.getMessage());
		}
		}
		break;
			}
		}
		catch(EmployeeException e)
		{
			System.out.println(e.getMessage());
		}
		}
		break;
		}
		}
		catch(EmployeeException e)
		{
			System.out.println(e.getMessage());
		}
		}
		
	}
	

    private static void deleteEmp() {
        System.out.println("Enter Employee Id whom Information You Want to Delete:");
        int dempId = sc.nextInt();
        EmployeeService emp = new EmployeeServiceImpl();
        int a = emp.deleteEmp(dempId);
        if(a == 1){
            System.out.println("Data is Deleted");
        }
        else if(a == 0){
            System.out.println("No Such Employee is found");
        }
        
        
    }
}
