package com.cg.hms.dao;

import java.util.HashMap;

import com.cg.hms.dto.Patient;
import com.cg.hms.exception.PatientException;

public interface PatientDao {
	
	public int addPatient(Patient ee) throws PatientException;
	public Patient getPatientDetails(int regNum);
	
 
public int delPatient(int regNum);
public Patient SearchByRegNum(int regNum);
public Patient SearchByName(String patName);
public Patient SearchByRoomNum(int roomNum);
public Patient UpdatePatient(int regNum, int RoomNum);
public HashMap<Integer, Patient> fetchAll();
}
