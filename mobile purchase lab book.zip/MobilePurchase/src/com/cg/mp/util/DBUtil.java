package com.cg.mp.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.cg.mp.bean.MobileBean;

public class DBUtil {
	public static Map<Integer,MobileBean> cmps=new HashMap<Integer, MobileBean>();

	public static int addCust(MobileBean cc)
	{
		
		int k=Integer.parseInt(cc.getMbId());
		System.out.println(k);
	    cmps.put(k,cc);
	    return k ;
	    
	}
	public static Map<Integer,MobileBean> getCustDetails(String MbID)
	{
		return cmps;
	}
	
	
	    /*Map.Entry<Integer, MobileBean> temp = null;
	    MobileBean mpb = null;
	    Iterator<Map.Entry<Integer, MobileBean>> mb=cmps.entrySet().iterator();
	    while(mb.hasNext()){
	        temp = mb.next();
	        if(temp.getValue().getMbId() == MbID){
	            mpb = temp.getValue();
	            return mpb;*/
	
}
