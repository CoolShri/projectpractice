package com.cg.hms.util;

import java.util.HashMap;

import com.cg.hms.dto.Patient;

public class PatientUtil {
	static HashMap<Integer , Patient> hmap= new HashMap<>();
	
	
	public int addPatient(Patient ee) {
		hmap.put(ee.getRegNum(), ee);
		return ee.getRegNum();
	}

	

	public HashMap<Integer, Patient> fetchAll() {
		return hmap;
	}


	public Patient SearchByName(String patName) {
		if(hmap.containsValue(patName))
		{
			return hmap.get(patName);
		}
		return null;
	}

	public Patient SearchByRoomNum(int roomNum) {
		return null;
	}

	public Patient UpdatePatient(int regNum, int roomNum) {
		
		return null;
	}

	public int delPatient(int regNum) {
		hmap.remove(regNum);
		return regNum;
	}

	

	public Patient SearchRegNum(int regNum) {
		return null;
	}






	public Patient getPatientDetails(int regNum) 
	{
		if(hmap.containsKey(regNum))
		{
			return hmap.get(regNum);
		}
		return null;
	}
	

}
