package com.cg.tms.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.tms.bean.TicketBean;
import com.cg.tms.bean.TicketCategory;
import com.cg.tms.exception.TicketException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;
import com.cg.tms.util.Util;

public class MainUI {
	static int max = 1000000;
	static int min = 10000;
	static int range = max - min + 1;
	static String details = null;
	static int rand = 0;
	static String priority = null;
	static String option = null;
	static String comments = null;
 
	static Scanner sc = null;
	static TicketService tService = null;
	static BufferedReader buffer = new BufferedReader(new InputStreamReader(
			System.in));

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		tService = new TicketServiceImpl();
		String choice;
		while (true) {
			System.out.println(" Welcome to ITIMD Help Desk "
					+ "\n 1.Raise a Ticket " + "\n 2.Exit from the system");
			choice = sc.next();
			try {
				/*if (tService.valiadteChoice(choice)) {*/
				if (tService.valiadteOption(choice)) {
					performOperation(Integer.parseInt(choice));
				}
			} catch (TicketException e) {
				System.out.println(e.getMessage());
			}
		}

	}

	private static void performOperation(int choice) {
		switch (choice) {
		case 1:
			raiseTicket();
			break;
		case 2:
			System.out.println("Thank you for choosing ITIMD.");
			System.exit(0);
		case 3:
			viewticket();
			break;
		default:
			System.out.println("Wrong Input");
			break;
		}

	}

	private static void viewticket() {
		// TODO Auto-generated method stub
		Map<Integer,TicketBean> mm= Util.getTicketLog();
		Iterator<TicketBean> it = mm.values().iterator();
		while(it.hasNext()){
			TicketBean temp = it.next();
			System.out.println(temp);
			}
		
	}

	private static void raiseTicket() {
		int k=1;
		/*System.out.println("Select Ticket Category from below List: \n"
				+ "1:Software Installation\n" + "2:Mailbox creation\n"
				+ "3:network issues");*/
		
		  List<TicketCategory> temp = tService.listTicketCategory(); 
		//  System.out.println("A");
		/*  System.out.println(temp);*/
		  Iterator itList = temp.iterator(); 
		  TicketCategory tCat = null;
		 while(itList.hasNext()){ 
			 tCat = (TicketCategory) itList.next();
			 System.out.println((k++)+" : "+tCat.getCategoryName()); 
			 	}
		 
		System.out.print("Enter Option : ");
		option = sc.next();
		try {
			if (tService.valiadteOption(option)) {
				System.out.println("Enter Description related to issue:");

				try {
					details = buffer.readLine();
				} catch (IOException e) {
					e.printStackTrace();
				}

				System.out.print("Enter Priority (1. low 2. medium 3.high): ");
				priority = sc.next();
				try {
					if (tService.valiadteOption(priority)) {
						if (Integer.parseInt(priority) == 3) {
							comments = "This ticket needs to be checked immediately";
						} else if (Integer.parseInt(priority) == 2) {
							comments = "This ticket needs to be checked";
						} else if (Integer.parseInt(priority) == 1) {
							comments = "This ticket needs to be checked when admin wants to";
						}
						rand = (int) (Math.random() * range) + min;
						TicketBean tBean = new TicketBean(
								Integer.toString(rand), option, details,
								priority, "new", comments);
						boolean flag = tService.raiseNewTicket(tBean);
						if (flag==true) {
							System.out.println("Ticket Number " + rand
									+ " logged successfully at "
									+ LocalDateTime.now());
						}
					}
				} catch (TicketException e) {
					System.out.println(e.getMessage());
				}
			}
		} catch (TicketException e) {
			System.out.println(e.getMessage());
		} 
}
}
