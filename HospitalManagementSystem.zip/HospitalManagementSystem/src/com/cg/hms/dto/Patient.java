package com.cg.hms.dto;

public class Patient implements Comparable<Patient> {
	private int regNum;
	private String patName;
	private int age;
	private int roomNum;
	
	public Patient(int regNum, String patName, int age, int roomNum) 
	{
		super();
		this.regNum = regNum;
		this.patName = patName;
		this.age = age;
		this.roomNum = roomNum;
	}
	
	

	
	@Override
	public String toString() {
		return "Patient [regNum=" + regNum + ", patName=" + patName + ", age="
				+ age + ", roomNum=" + roomNum + "]";
	}




	public int getRegNum() {
		return regNum;
	}



	public void setRegNum(int regNum) {
		this.regNum = regNum;
	}



	public String getPatName() {
		return patName;
	}



	public void setPatName(String patName) {
		this.patName = patName;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public int getRoomNum() {
		return roomNum;
	}



	public void setRoomNum(int roomNum) {
		this.roomNum = roomNum;
	}
	@Override
	public int compareTo(Patient p)
	{
		if(p.regNum<this.regNum)
		{
			return -1;
		}
		else if(p.regNum == this.regNum)
			{
				return 0;
			}
			else 
				{
					return 1;
				}
			}
		}
	


