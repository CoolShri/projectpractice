package com.cg.tms.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.ticketException;
import com.cg.tms.service.TicketServiceImpl;
import com.cg.tms.util.Util;

public class MainUI {

	public static void main(String[] args) throws ticketException, IOException {
		Util util= new Util();
		
		System.out.println("Welcome to ITIMD Help Desk ");
		while(true)
		{
			 Scanner sc=new Scanner(System.in);
		
			System.out.println("select your operation");
			System.out.println("1.Raise a Ticket");
		
		    System.out.println("2.Exit From System");
		
			int choice=sc.nextInt(); 
			
			
			switch(choice)
			{
			case 1:RaiseTicket();
				break;
			
		    default:System.exit(0);

			}

	}

}

	private static void RaiseTicket() throws ticketException, IOException {
		TicketServiceImpl ticketSer=new TicketServiceImpl();
		  Random r=new Random();
		 Scanner sc=new Scanner(System.in);
		
		;
		System.out.println( Util.getTicketCategoryEntries());
	  

		
          System.out.println("enter option");
		  int choice1=sc.nextInt(); 
		
		
		switch(choice1)
		{
		case 1:
			String Ticketcatid1="1";
			String TicketCat1="Software Installation";
			System.out.println("enter description");
			 BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
				String desc1=br.readLine();
				
			System.out.println("Enter Priority");
			System.out.println("1.low");
			System.out.println("2.medium");
			System.out.println("3.high");
			String priority1=sc.next();
			String TicketNO1=Integer.toString(r.nextInt(1000));
			String itimdComments1="new Ticket";
			String Ticketstatus1="new";
			DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now1 = LocalDateTime.now();
		
			
		 TicketBean tbean1=new TicketBean(Ticketcatid1, TicketCat1);
			TicketCategory tbeab1= new TicketCategory(TicketNO1 ,TicketCat1,
					 desc1,  priority1,
					 Ticketstatus1, itimdComments1);
			ticketSer.raiseNewTicket(tbean1);
		if(	ticketSer.raiseNewTicket(tbean1))
		{
			System.out.println("Ticket Number "+TicketNO1+" logged successfully at "+dtf1.format(now1));
		}
			break;
		
		case 2:
			String Ticketcatid2="2";
			String TicketCat2="Mailbox creation";
			System.out.println("enter description");
			 BufferedReader br2 = new BufferedReader(new InputStreamReader(System.in)); 
				String desc2=br2.readLine();
			System.out.println("Enter Priority");
			System.out.println("1.low");
			System.out.println("2.medium");
			System.out.println("3.high");
			String priority2=sc.next();
			
			String TicketNO2=Integer.toString(r.nextInt(1000));
			String itimdComments2="new Ticket";
			String Ticketstatus2="new";
			//taking current time
			DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now2 = LocalDateTime.now();
			
		
			TicketCategory tbeab2= new TicketCategory(TicketNO2 ,TicketCat2,
					 desc2,  priority2,
					 Ticketstatus2, itimdComments2);
			
			 TicketBean tbean2=new TicketBean(Ticketcatid2, TicketCat2);
				ticketSer.raiseNewTicket(tbean2);
			 if(	ticketSer.raiseNewTicket(tbean2))
				{
					System.out.println("Ticket Number "+TicketNO2+" logged successfully at "+dtf2.format(now2));
				}
			break;
		case 3:
			String Ticketcatid3="2";
			String TicketCat3="network issue";
			System.out.println("enter description");
			 BufferedReader br3 = new BufferedReader(new InputStreamReader(System.in)); 
				String desc3=br3.readLine();
			System.out.println("Enter Priority");
			System.out.println("1.low");
			System.out.println("2.medium");
			System.out.println("3.high");
			String priority3=sc.next();
			String TicketNO3=Integer.toString(r.nextInt(1000));
			String itimdComments3="new Ticket";
			String Ticketstatus3="new";
			//taking current time
			DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now3 = LocalDateTime.now();
			
			TicketCategory tbeab3= new TicketCategory(TicketNO3 ,TicketCat3,
					 desc3,  priority3,
					 Ticketstatus3, itimdComments3);
			
			
			
			

			 TicketBean tbean3=new TicketBean(Ticketcatid3, TicketCat3);
			
			 if(	ticketSer.raiseNewTicket(tbean3))
				{
					System.out.println("Ticket Number "+TicketNO3+" logged successfully at "+dtf3.format(now3));
				}
			break;
	    default:System.exit(0);

		}
	}
}
