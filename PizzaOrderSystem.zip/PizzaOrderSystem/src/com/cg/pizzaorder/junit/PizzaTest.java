 package com.cg.pizzaorder.junit;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;


public class PizzaTest {
	
	IPizzaOrderDAO ipd1=new PizzaOrderDAO();
	
	@Test
	public void testaddPat() throws PizzaException
	{
		Assert.assertEquals(111, ipd1.placeOrder(new Customer("Yashi","Lucknow","Phone"),new PizzaOrder(111,12000,450)));
	}
	
	@Test
	public void testgetPat() throws PizzaException
	{
		ipd1.placeOrder(new Customer("Yashi","Lucknow","Phone"),new PizzaOrder(111,12000,450));
		Assert.assertNotNull(111);
	}
}