package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.LoginDaoImpl;
import com.cg.dto.Login;

public class LoginServiceImpl {
	LoginDaoImpl LoginDao=null;
	
	public LoginServiceImpl() throws SQLException 
	{
		LoginDao=new LoginDaoImpl();
	}
	
	public Login getUserDetails(String unm)throws SQLException
	{
		return LoginDao.getUserDetails(unm);
		
	}

}
