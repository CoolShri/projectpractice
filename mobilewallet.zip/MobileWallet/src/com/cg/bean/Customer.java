package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;




import org.hibernate.annotations.Table;

@Entity
@Table(appliesTo = "Customer")
public class Customer {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
int cust_id;
String name;
String phoneNo;
String dob;
String id_proof;
String address;
public Customer()
{
	
}
public Customer( String name, String phoneNo, String dob,
		String id_proof, String address) {
	super();

	this.name = name;
	this.phoneNo = phoneNo;
	this.dob = dob;
	this.id_proof = id_proof;
	this.address = address;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getId_proof() {
	return id_proof;
}
public void setId_proof(String id_proof) {
	this.id_proof = id_proof;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getCust_id() {
	return cust_id;
}
public void setCust_id(int cust_id) {
	this.cust_id = cust_id;
}

@Override
public String toString() {
	return "Customer [cust_id=" + cust_id + ", name=" + name + ", phoneNo="
			+ phoneNo + ", dob=" + dob + ", id_proof=" + id_proof
			+ ", address=" + address + "]";
}



}
