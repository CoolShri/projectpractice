package com.cg.tms.exception;
// excetion class
public class ticketException extends Exception {
	ticketException(String msg)
	{
		super(msg);
	}
}
