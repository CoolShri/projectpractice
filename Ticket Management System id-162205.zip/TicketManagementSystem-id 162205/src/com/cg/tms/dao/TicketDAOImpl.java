package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.ticketException;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO{
Util util=new Util();
	@Override
	public boolean raiseNewTicket(TicketBean tikcetBean)  throws ticketException{
		if( util.raiseNewTicket(tikcetBean))
			{
			return true;
			}
		return false;
	}

	@Override
	public List<TicketCategory> listTicketCategory()  throws ticketException {
	//covert to list and fetching
		util.getTicketCategoryEntries();
		//System.out.println(util.getTicketCategoryEntries());
		List<TicketCategory> list = new ArrayList<TicketCategory>();
	return list;
		
		
	}

}
