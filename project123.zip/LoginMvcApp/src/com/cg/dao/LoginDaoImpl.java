package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl 
{
Connection con=null;
PreparedStatement pst=null;
ResultSet rs=null;
Login usr=null;

public LoginDaoImpl() throws SQLException
{
	
}
public Login getUserDetails(String uname) throws SQLException
{
	con=DBUtil.getCon();
	
	System.out.println("in dao get connection "+con);
	String sql="select * from logintbl where USERNAME=?";
	
	pst=con.prepareStatement(sql);
	pst.setString(1, uname);
	rs=pst.executeQuery();
	rs.next();
	usr=new Login(rs.getString(1),rs.getString(2));
	return usr;
	
}
}
