package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.ticketException;

public class TicketServiceImpl implements TicketService {
	//object of TicketDAOImpl
TicketDAOImpl tdao= new TicketDAOImpl();
	@Override
	public boolean raiseNewTicket(TicketBean ticketBean)  throws ticketException {
		 return tdao.raiseNewTicket(ticketBean);
		
		
		
		
	}

	@Override
	//calling dao methods
	public List<TicketCategory> listTicketCategory()  throws ticketException {
		
	return tdao.listTicketCategory();
	}

}
