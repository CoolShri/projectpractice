package com.cg.mp.dao;

import java.util.Map;

import com.cg.mp.bean.MobileBean;
import com.cg.mp.exception.MobilePurchaseException;
import com.cg.mp.util.DBUtil;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao {

	@Override
	public int addDetails(MobileBean details) throws MobilePurchaseException {
		
		return DBUtil.addCust(details);
	}

	@Override
	public MobileBean getDetails(String mobileId)
	{
	Map<Integer,MobileBean> map3=DBUtil.getCustDetails(mobileId);
	if(map3.containsKey(mobileId))
	{
		return map3.get(mobileId);
	}
	return null;
	}

	
}
