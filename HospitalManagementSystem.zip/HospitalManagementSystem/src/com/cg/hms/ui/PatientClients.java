package com.cg.hms.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.hms.dto.Patient;
import com.cg.hms.exception.PatientException;
import com.cg.hms.service.PatientService;
import com.cg.hms.service.PatientServiceImpl;

public class PatientClients {
	static PatientService pts=null;
	static Scanner sc =new Scanner(System.in);
	static Random r= new Random();

	public static void main(String[] args) throws PatientException 
	{
		pts= new PatientServiceImpl();
		
		while (true)
		{
		System.out.println("Welcome to the hospital");
		System.out.println("Select operations");
		System.out.println("1.Add Patient");
		System.out.println("2.Delete Patient");
		System.out.println("3.fetch all Patient");
		System.out.println("4.Search patient by Reg Num");
		System.out.println("5.Search patient by name");
		System.out.println("6.Search by Room number");
		System.out.println("7.Update Patient Information");
		
		int choice = sc.nextInt();
		performOperation(choice);
		}

	}

	private static void performOperation(int choice) throws PatientException 
	{
		switch(choice)
		{
		case 1 : addPatient();break;
		case 2 : fetchPat();break;
		case 3 : delPatient();break;
		case 4 : SearchByRegNum();break;
		case 5 : SearchByName();break;
		case 6 : SearchByRoomNum();break;
		case 7 : UpdatePatient();break;
		}
		
	}
	private static void addPatient() throws PatientException 
	{
		System.out.println("Patient Details");
		System.out.println("Enter patient Name");
		String patName =sc.next();
		System.out.println("Enter Patient Age");
	    int Age = sc.nextInt();
		System.out.println("Enter Patient Room Number");
		int roomNum= sc.nextInt();
		Patient p = new Patient(Math.abs(r.nextInt(1000)), patName, Age, roomNum);
		pts.addPatient(p);
		System.out.println("Your data has been saved");
		System.out.println("Your reg num is"+p.getRegNum());
		
	}
	
	private static void SearchByRegNum() 
	{
		System.out.println("Enter Registration Number");
		int regNum= sc.nextInt();
		if(pts.getPatientDetails(regNum) != null)
		{
			System.out.println(pts.getPatientDetails(regNum));
		}
		else
			System.out.println("Data not found");
		
		
	}
	
	

	private static void UpdatePatient() {
		
	}

	private static void SearchByRoomNum() {
		
	}

	

	private static void SearchByName() {
		
	}



	private static void fetchPat() {
		
	}

	
	
private static void delPatient() 
{
		
	}


}
