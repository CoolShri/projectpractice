package com.cg.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext con = new ClassPathXmlApplicationContext("config2.xml");
		Department D = con.getBean(Department.class);
		D.DisplayDetails();
	}

}
