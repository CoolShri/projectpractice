package com.cg.pizzaorder.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaException {
		IPizzaOrderDAO pod=new PizzaOrderDAO();
		return pod.placeOrder(customer, pizza);
		
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		IPizzaOrderDAO pod=new PizzaOrderDAO();
		return pod.getOrderDetails(orderid);
	}

	@Override
	public Map<Integer, PizzaOrder> pizzOrderDataSet() throws PizzaException {
		IPizzaOrderDAO pod=new PizzaOrderDAO();
		return pod.pizzOrderDataSet();
	}

	@Override
	public boolean validateMobileNumber(String phone) {
		String namePattern="[0-9]+";
		if(Pattern.matches(namePattern, phone))
		{
			if(phone.length()==10)
			{
				return true;
			}
			else
			{
				System.out.println("Mobile number is of 10 digits");
				return false;
			}
		}
		else
		{
			System.out.println("Mobile number should contain only digits");
			return false;
		}
	}


}
